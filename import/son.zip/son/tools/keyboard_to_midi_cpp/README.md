# keyboard_to_midi_cpp (macOS)

Petit programme C++ qui transforme le clavier AZERTY en clavier piano et envoie des messages MIDI USB à une Teensy.

## Dépendances (macOS)
```bash
brew install sdl2 rtmidi cmake pkg-config
